# Bycicle Renting Data Exploration
## by Sunny


## Dataset

> This data set includes information about individual rides made in a bike-sharing system covering the greater San Francisco Bay area.The original dataset include entries with 15 features ['bike_id', 'bike_share_for_all_trip', 'duration_sec', 'end_station_id',
       'end_station_latitude', 'end_station_longitude', 'end_station_name',
       'end_time', 'rental_access_method', 'start_station_id',
       'start_station_latitude', 'start_station_longitude',
       'start_station_name', 'start_time', 'user_type'].
> The original dataset is downloaded by months, I conbined the 12 months data in 2019 into one single csv file named 'combined_csv.csv'. This file is used in the data exploration.
> Dataset link:https://www.fordgobike.com/system-data


## Summary of Findings

> In the preliminary examination of the data set, I decide to investigate with these questions in mind:
> 1. how long the avg trip takes?
> 2. What is the user segment distribution?
> 3. When are the most trips take place in terms of time of day?day of the week, and month of the year?
> In the exploration, with these 3 question in mind, I have several key findings in responding to the questions above:
1. Hourly usage shows less customer usage during night time, the peak usage occurs during commuting peak hour 7-9 am, 4-6 pm, especially for subscribers segment.
2. In the figure of Monthly usage with different user type in 2019, I noticed the number of subscribers and customers in dec are almost same, while in other months, the number of subscribers are many more than customer's number. Seasonal trend also shows less usage during the 4th quarter, which might due to the Christmas season.
3. Customer user count in weekdays and weekends is almost same, while subscriber tend to take more trips during workdays rather than weekends. The subscribers' usage shows higher pattern on commuting.
4. On weekday usage with different user type in 2019 figure, we can see less total trips count in weekends than workdays. We can also find the customer segment usage in  workdays and weekends are almost same, while subscriber tend to take more trips during workdays. 
4. On the user segment plot, we can easily see the subscribers user count is almost fourfold of the customer segment. However the figure of the Average trip duration for different user types shows customers tend to take longer trip than the subscribers.
5. the figure of trip duration by hours and user types shows the customer have longer trip over the year while subscribers tend to have shorter duration trip. This also shows the subscribers tend to taking roughly same-duration trips, which could due to the commuting reason.
The highest rental duration is in morning time 4-5am.
6. The figure of trip duration in different weekdays by different user types shows the customers tend to have longer trips than the subscribers, easpecially during weekends.
7. The figure of trip duration by months and user types shows the customer have longer trip over the year while subscribers tend to have shorter duration trip. This also shows the subscribers tend to taking roughly same-duration trips, which could due to the commuting reason. Customers take shorter trip during Dec, which might due to Christmas season.


## Key Insights for Presentation

> 1. Show the analysis of the trip duration for different time frame and user segments
> 2. Show the analysis of the trip counts for different time frame and user segments
In the light of the above findings, we can see the diifferent usage pattern of the user segments. The subscribers tend to use the bicycle for commuting, who have more trips during workdays and similar trip duration. The customers tend to use bicycle for leisure use, who have longer trip duration and higher usage during weekends. The company can use such analysis results to better tailor their operation stretagy. Improvement advice: I also find the rental access data is incomplete with 2386145 empty entries, which could be very helpful to get the full picture of the customer channels and further develop the more targeted sale campaign. Based on what we have in the exsiting data, we know that customers tend to use app rather than clipper card. 